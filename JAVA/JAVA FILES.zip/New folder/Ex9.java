package ust.examples;

public class Ex9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Integer myInt = 100;
String myString = myInt.toString();

	

System.out.println(myString.length());
}
}