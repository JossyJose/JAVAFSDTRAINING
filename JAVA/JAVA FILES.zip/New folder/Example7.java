package ust.examples;
//unary operator
public class Example7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      int i=10;
      
		System.out.println(i++)	;
		i++;
		System.out.println(i)	;
		++i;
		System.out.println(i--)	;
		--i;
	}

}
