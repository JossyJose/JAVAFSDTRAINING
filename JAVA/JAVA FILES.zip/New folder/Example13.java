package ust.examples;
//do while loop example 2
public class Example13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int arr[] = {2,11,45,9};//i starts with 0 as array starts with zero

int i=0;
do {
	System.out.println(arr[i]);
	i++;
       }while(i<4);



	}

}
