package ust.examples;
//example for do while loop
public class Example6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
               int  i=10;
                 do {
                	 System.out.println("hello");
                	 i++;
                 }while(i<10);
	}

}
