package ust.examples;

public class Ex14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s1 = "hello";
		String s2 = "";
		String s3 = "me";
		System.out.println(s1.compareTo(s2));
		System.out.println(s1.compareTo(s3));
	}

}
