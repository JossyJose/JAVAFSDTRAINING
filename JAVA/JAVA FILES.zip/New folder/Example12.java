package ust.examples;
//switch case example 2
public class Example12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
           
		char ch='b';
		switch(ch) {
		
		case 'd':
			System.out.println("case1");
			break;
			
		case 'b':
			System.out.println("case2");
			break;
			
		case 'x':
			System.out.println("case3");
			break;
			
		case 'y':
			System.out.println("case4");
			break;
			
			default:
				System.out.println("Default");
		}
		
		
		
	}

}
