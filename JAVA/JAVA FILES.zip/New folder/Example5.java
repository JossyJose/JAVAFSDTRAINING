package ust.examples;
//example of while loop
public class Example5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a= 0;
		while(a<10){
			System.out.println(a);
			a++;
		}
		
		
	}

}
