package ust.examples;
// String Replace example
public class Example17 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str = "Replacing Region";
		System.out.println(str.replace('A', 'R'));
		
		System.out.println(str.replaceFirst("Re", "Ra"));
		
		System.out.println(str.replaceAll("Re", "Ra"));
		
		
		
		
		
		
		
	}

}
