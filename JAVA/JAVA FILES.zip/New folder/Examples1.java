package ust.examples;



public class Examples1 {
	String name;//instance variable
	float price;//instance variable
	static int count;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age=10;//local variable
		System.out.println(age);
		Examples1 e=new Examples1();
		e.name="abhinaya";
		count=6;
		System.out.println(e.name);
		System.out.println(count);
	}

}
