package ust.examples;

public class CollectionEx1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i = 5;
Integer obj =new Integer(i);
int j = obj.intValue();
Double d = 5.5;
System.out.println(j);

Double obj1=new Double(d);
Double dd=obj.doubleValue();
System.out.println(dd);
	}

}
