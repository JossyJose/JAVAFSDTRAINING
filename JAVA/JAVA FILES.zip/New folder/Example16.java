package ust.examples;
//String ends with example
public class Example16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
              
		String strOrig = "Hello World";
		
		if(strOrig.endsWith("World")) {
			System.out.println("String ends with World");
		}else
		{
			System.out.println("String does not end with World");
		}
	}

}
