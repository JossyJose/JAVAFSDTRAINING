package ust.examples;

//import statement

import java.util.Date;

public class Example21 {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Date d = new Date();
		System.out.println(d.toString());
	}

}
