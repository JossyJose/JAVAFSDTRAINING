package ust.examples;
//example of switch case
public class Example4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String colourcode="red";
switch(colourcode){
case "red":
	System.out.println("stop");
	break;
case "green":
	System.out.println("go");
	break;
	
case "orange":
	System.out.println("ready");
	break;
	
	default:
		System.out.println("go home");
		break;
}
	
	}
	

	}
