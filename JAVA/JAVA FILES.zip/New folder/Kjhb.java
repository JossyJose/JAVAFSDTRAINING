package ust.examples;

public class Kjhb {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	int g= 3;
	System.out.println(++g*8);
			
		}
	}


