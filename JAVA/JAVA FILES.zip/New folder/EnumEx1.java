package ust.examples;
enum Level{
	LOW,
	MEDIUM,
	HIGH
}



public class EnumEx1 {

	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Level myVar = Level.MEDIUM;
System.out.println(myVar);
		
	}

}
